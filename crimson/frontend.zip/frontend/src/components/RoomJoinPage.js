import React, { Component } from "react";

export default class RoomJoinPage extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <p>This is the room join page</p>;
  }
}